/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _EMU_INC_HASH_MD5_H
#define _EMU_INC_HASH_MD5_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_md5.h"

#endif // _EMU_INC_HASH_MD5_H
