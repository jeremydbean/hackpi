#define VERSION "6.0.0"
#define VERSION_JAHR "2019"
