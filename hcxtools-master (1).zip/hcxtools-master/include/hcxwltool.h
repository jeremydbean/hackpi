#define HCX_INPUT_WORDLIST		'i'
#define HCX_OUTPUT_WORDLIST		'o'
#define HCX_SWEEP_LEN			'1'
#define HCX_DIGIT			'2'
#define HCX_XDIGIT			'3'
#define HCX_LOWER			'4'
#define HCX_UPPER			'5'
#define HCX_CAPITAL			'6'
#define HCX_STRAIGHT			'7'
#define HCX_HELP			'h'
#define HCX_VERSION			'v'

#define LINEIN_MAX 128
