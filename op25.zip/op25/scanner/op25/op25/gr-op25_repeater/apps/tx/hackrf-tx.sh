#! /bin/sh

./op25_tx.py --gains 'RF:0,IF:0' -n 2 -r -e -i --args 'hackrf' -f 925005000
