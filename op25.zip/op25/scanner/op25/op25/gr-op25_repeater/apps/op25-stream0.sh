./rx.py -l http:127.0.0.1:8080 --args "rtl=0" --gains 'lna:36' -O loop0 -D cqpsk -S 960000 -T trunk.tsv -q 0 -d -200 -v 1 -2 -u 23456 -U 2> stderr-stream0.2
