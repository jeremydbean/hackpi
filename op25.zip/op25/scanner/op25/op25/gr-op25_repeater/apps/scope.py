#! /usr/bin/env python

s="""
*****************************************************************************
*
* The scope.py app has been deprecated; it has been replaced by rx.py .
*
* See file "README" in this directory for further information about rx.py .
*
* If you really want to use scope.py, 
* 1) 'sudo make uninstall' the currently installed version of OP25
* 2) 'git checkout bcef5dfc295a76aa219709c3492285b81652a2dd'
* 3) rebuild and re-install OP25, starting with an empty 'build' directory
*
*****************************************************************************
"""

if __name__ == '__main__':
	print s
