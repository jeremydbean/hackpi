#! /bin/sh

sudo ./rx.py --args 'rtl' -N 'LNA:47' -S 250000 -f 857.2125e6 -o 17e3 -q 0 -O loop0 -T trunk.tsv -V -2 -U 2> stderr-stream0.2
